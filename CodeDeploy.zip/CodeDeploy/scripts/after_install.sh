#!/bin/bash

# Reiniciar o serviço Apache
systemctl restart httpd